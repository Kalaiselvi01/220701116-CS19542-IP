<?php

$db_connect = mysqli_connect('localhost','root','','store_db') or die('connection failed');

?>